#!/bin/python3

#Variable and Methods
quote = "All is fair in love and war."
print(quote.upper()) #uppercase
print(quote.lower()) #lowercase
print(quote.title()) #title case

print(len(quote))

name = "Health" #string
age = 30 #int int(30)
gpa = 3.7 #float float(3.7)

print(int(age))
print(int(30.1))

print("My name is" + name + "and I am" + str(age) + "yers old .")
age += 1
print(age)

birthday = 1
age += birthday
print(age)

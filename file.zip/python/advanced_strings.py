#!/bin/python3

import sys #system functions and parameters
from datetime import datetime as dt #import as alias

print(dt.now())

my_name = "Fauzi"
print(my_name)
print(my_name[-1])

sentence = "This is a sentence"
print(sentence[:4])

print(sentence.split())

sentence_split = sentence.split()
sentence_join = ' '.join(sentence_split)
print(sentence_join)

quote = "He said, \"give me all money\""

print(quote)

too_much_space =  "                          Hello                                "
print(too_much_space.strip())

print("a" in "Apple")

letter = "A"
world = "Apple"
print(letter.lower() in world.lower()) #IMproved

movie = "The Hangover"
print("My favorite movie is {}.".format(movie))

#Dictionary - key/values pairs {}

drinks = {"White Russian":7,"Old Fashion":10,"Lemon Drop":8} #drink is key , price is value

print(drinks)

employees = {"Finance":["Bob","linda","Tina"],"IT":["Gene","Louise","Teddy"], "HR":["jimmy","Jr.","Mort"]}
print(employees)

employees["Legal"] = ["Mr. Frond"] #add new key:value pair

print(employees)

employees.update({"Sales":["Andie","Ollie"]}) #add new key:value pair
print(employees)

drinks["White Russian"] = 8
print(drinks)
























#!/bin/python3
import sys #system functions and pramaters
from datetime import datetime as dt #import with alias

print(sys.version)
print(dt.now())


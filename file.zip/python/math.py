#!/bin/python3

#Math 
print(100+100) #add
print(100 -100) #subtract
print(100 * 100) #multiple
print(100 / 100) #devide
print(100 +100 - 100 * 100 / 100 + 100) #PEMDAS
print(50 ** 2) #exponentials
print(50 % 6) #Modulo
print(50 / 6)
print(50 // 6) #no leftcovers

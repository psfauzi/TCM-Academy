def nl():
	print('\n')
	
	
nl()

#Lists - Have brackets []

movies = ["When Harry Met Sally","The Hangover", "The Perks Of Being a Wallflower", "The Exorcist"]

print(movies[1]) #return the second item 
print(movies[0]) #return the first item in the list
print(movies[1:4]) 
print(movies[1:])
print(movies[:2])
print(movies[-1])

print(len(movies))
movies.append("AWS")
print(movies)

movies.pop()
print(movies)

movies.pop(0)
print(movies)

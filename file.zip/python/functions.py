#!/bin/python3

#functions
print("Here is an example functions:")

def who_am_i(): #this is a function 
	name = "Fauzi"
	age = 30
	print("My name is " + name + " and my age is " + str(age))

who_am_i()

#Adding parameters
def add_one_hundred(num):
	print(num + 100)

add_one_hundred(100)

#Multiple paramters
def add(x,y):
	print(x + y)
	
add(7,7)

def multiplay(x,y):
	return x * y
	
print(multiplay(7,7))


def square_root(x):
	print(x ** .5)
	
square_root(64) 

def newline():
	print('\n')
	
newline()
	

#For Loops - start to finish 
vegetables = ["cucumbar", "spinach","cabbage"]
for x in vegetables:
	print(x)

#While loops - Execute as long true

i = 1
while i < 10:
	print(i)
	i += 1
	

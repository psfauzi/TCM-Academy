#!/bin/python3

#print string
print("Hello, World")
print('\n')
print('Hello, World')

print("""This is string runs multiple lines!""") #triple quote for multi-line

print("This STing is "+"awesome") #we can also concatination

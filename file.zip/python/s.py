#!/bin/python3

import socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
HOST = '127.0.0.1'
PORT = 7777

s.connect((HOST,PORT)) 



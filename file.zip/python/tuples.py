def nl():
	print('\n')
	
#Tuples - Do not Change, ()

grades = ("a","b","c",","d","f")
print(grades[1])

